<?php
error_reporting(E_ALL);
ini_set('display_errors', 0); // Hide errors in production, output JSON instead
header('Content-Type: application/json; charset=utf-8');

// Database configuration
$db_host = 'sql301.infinityfree.com';
$db_user = 'if0_41857535';
$db_pass = 'Jm3cN2fzLc';
$db_name = 'if0_41857535_filmaciones'; // Adjust this to the actual DB name if different

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de conexión a la base de datos']);
    exit;
}

// Request processing
$method = $_SERVER['REQUEST_METHOD'];
$request_uri = isset($_GET['request']) ? '/' . rtrim($_GET['request'], '/') : '/';
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE); //convert JSON into array

// Auth Middleware
$user = null;
function checkAuth() {
    global $pdo, $user;
    $headers = apache_request_headers();
    $authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : null);
    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode(['error' => 'No autorizado']);
        exit;
    }
    
    $token = str_replace('Bearer ', '', $authHeader);
    
    $stmt = $pdo->prepare("SELECT user_id FROM user_sessions WHERE token = ?");
    $stmt->execute([$token]);
    $session = $stmt->fetch();
    
    if (!$session) {
        http_response_code(401);
        echo json_encode(['error' => 'No autorizado']);
        exit;
    }
    
    $stmt = $pdo->prepare("SELECT id, username, role, name FROM users WHERE id = ?");
    $stmt->execute([$session['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'No autorizado']);
        exit;
    }
}

function isAdmin() {
    global $user;
    if ($user['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Solo administradores']);
        exit;
    }
}

function canEdit() {
    global $user;
    if (!in_array($user['role'], ['admin', 'post_productor'])) {
        http_response_code(403);
        echo json_encode(['error' => 'Sin permiso de edición']);
        exit;
    }
}

function logAction($action, $entity_type = null, $entity_id = null, $details = null) {
    global $pdo, $user;
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_log (user_id, user_name, action, entity_type, entity_id, details) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$user['id'], $user['name'], $action, $entity_type, $entity_id, $details]);
    } catch(Exception $e) {}
}

function queryOne($sql, $params = []) {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch();
}

function queryAll($sql, $params = []) {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function execute($sql, $params = []) {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $pdo->lastInsertId();
}

function extractCodeAndName($str) {
    if (!$str) return ['code' => null, 'name' => null];
    $s = trim($str);
    $parts = explode(' ', $s);
    if (count($parts) > 1 && strpos($parts[0], '-') !== false) {
        return ['code' => $parts[0], 'name' => implode(' ', array_slice($parts, 1))];
    }
    return ['code' => 'EXT', 'name' => $s];
}

// Router
function matchRoute($route, $uri, &$params) {
    $routeRegex = preg_replace('/:[^\/]+/', '([^\/]+)', $route);
    $routeRegex = str_replace('/', '\/', $routeRegex);
    if (preg_match('/^' . $routeRegex . '$/', $uri, $matches)) {
        array_shift($matches);
        preg_match_all('/:([^\/]+)/', $route, $paramNames);
        foreach ($paramNames[1] as $index => $name) {
            $params[$name] = $matches[$index];
        }
        return true;
    }
    return false;
}

$params = [];

// ========== AUTHENTICATION ==========
if ($method === 'POST' && $request_uri === '/login') {
    $username = $input['username'] ?? '';
    $password = $input['password'] ?? '';
    $userDb = queryOne("SELECT * FROM users WHERE username = ? AND password = ?", [$username, $password]);
    if (!$userDb) {
        http_response_code(401);
        echo json_encode(['error' => 'Credenciales inválidas']);
        exit;
    }
    $token = bin2hex(random_bytes(16));
    execute("INSERT INTO user_sessions (token, user_id) VALUES (?, ?)", [$token, $userDb['id']]);
    echo json_encode(['token' => $token, 'user' => ['id' => $userDb['id'], 'username' => $userDb['username'], 'role' => $userDb['role'], 'name' => $userDb['name']]]);
    exit;
}

if ($method === 'POST' && $request_uri === '/logout') {
    $headers = apache_request_headers();
    $authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : null);
    if ($authHeader) {
        $token = str_replace('Bearer ', '', $authHeader);
        execute("DELETE FROM user_sessions WHERE token = ?", [$token]);
    }
    echo json_encode(['success' => true]);
    exit;
}

// All subsequent routes require authentication
checkAuth();

if ($method === 'GET' && $request_uri === '/me') {
    echo json_encode($user);
    exit;
}

// ========== DASHBOARD ==========
if ($method === 'GET' && $request_uri === '/dashboard') {
    $sem = queryOne("SELECT * FROM semesters WHERE is_active = 1");
    if (!$sem) {
        echo json_encode(['semester' => null, 'totalSubjects' => 0, 'completedSubjects' => 0, 'pendingSubjects' => 0, 'inProgressSubjects' => 0, 'nextSession' => null, 'recentSessions' => [], 'inProgressList' => []]);
        exit;
    }
    
    $total = queryOne("SELECT COUNT(*) as c FROM subjects WHERE semester_id = ?", [$sem['id']])['c'];
    $completed = queryOne("SELECT COUNT(*) as c FROM subjects WHERE semester_id = ? AND completed = 1", [$sem['id']])['c'];
    $inProg = queryOne("SELECT COUNT(DISTINCT fa.subject_id) as c FROM filming_assignments fa JOIN subjects s ON s.id = fa.subject_id WHERE s.semester_id = ? AND fa.status = 'in_progress'", [$sem['id']])['c'];
    $pending = max(0, $total - $completed - $inProg);

    $today = date('Y-m-d');
    $nextSession = queryOne("SELECT rs.*, fa.teacher_name, fa.phone, s.code as subject_code, s.name as subject_name FROM recording_sessions rs JOIN filming_assignments fa ON fa.id = rs.assignment_id JOIN subjects s ON s.id = fa.subject_id WHERE rs.session_date >= ? AND fa.status != 'cancelled' ORDER BY rs.session_date ASC, rs.start_time ASC LIMIT 1", [$today]);

    $recentSessions = queryAll("SELECT rs.*, fa.teacher_name, s.code as subject_code, s.name as subject_name, fa.status as assignment_status FROM recording_sessions rs JOIN filming_assignments fa ON fa.id = rs.assignment_id JOIN subjects s ON s.id = fa.subject_id JOIN semesters sem ON sem.id = s.semester_id AND sem.is_active = 1 ORDER BY rs.session_date DESC LIMIT 5");

    $inProgressList = queryAll("SELECT fa.*, s.code as subject_code, s.name as subject_name FROM filming_assignments fa JOIN subjects s ON s.id = fa.subject_id WHERE s.semester_id = ? AND fa.status = 'in_progress' ORDER BY fa.created_at DESC", [$sem['id']]);

    echo json_encode(['semester' => $sem, 'totalSubjects' => $total, 'completedSubjects' => $completed, 'pendingSubjects' => $pending, 'inProgressSubjects' => $inProg, 'inProgressList' => $inProgressList, 'nextSession' => $nextSession, 'recentSessions' => $recentSessions]);
    exit;
}

// ========== SEMESTERS ==========
if ($method === 'GET' && $request_uri === '/semesters') {
    echo json_encode(queryAll("SELECT * FROM semesters ORDER BY created_at DESC"));
    exit;
}
if ($method === 'POST' && $request_uri === '/semesters') {
    $name = $input['name'] ?? null;
    if (!$name) { http_response_code(400); echo json_encode(['error' => 'Nombre requerido']); exit; }
    try {
        execute("UPDATE semesters SET is_active = 0");
        execute("INSERT INTO semesters (name, is_active) VALUES (?, 1)", [$name]);
        echo json_encode(queryOne("SELECT * FROM semesters WHERE name = ?", [$name]));
    } catch(Exception $e) {
        http_response_code(409); echo json_encode(['error' => 'Ya existe ese semestre']);
    }
    exit;
}
if ($method === 'PUT' && matchRoute('/semesters/:id/activate', $request_uri, $params)) {
    execute("UPDATE semesters SET is_active = 0");
    execute("UPDATE semesters SET is_active = 1 WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}
if ($method === 'DELETE' && matchRoute('/semesters/:id', $request_uri, $params)) {
    execute("DELETE FROM semesters WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}

// ========== SUBJECTS ==========
if ($method === 'GET' && $request_uri === '/subjects') {
    $semId = $_GET['semester_id'] ?? null;
    if (!$semId) {
        $active = queryOne("SELECT id FROM semesters WHERE is_active = 1");
        if (!$active) { echo json_encode([]); exit; }
        $semId = $active['id'];
    }
    $subjects = queryAll("
        SELECT s.*, fa.id as assignment_id, fa.status as assignment_status, fa.last_hito_reached,
               fa.teacher_name, fa.script_status, fa.drive_link
        FROM subjects s
        LEFT JOIN filming_assignments fa ON fa.subject_id = s.id AND fa.status != 'cancelled'
        WHERE s.semester_id = ?
        ORDER BY s.code ASC
    ", [$semId]);
    echo json_encode($subjects);
    exit;
}
if ($method === 'POST' && $request_uri === '/subjects') {
    $code = $input['code'] ?? null;
    $name = $input['name'] ?? null;
    $semester_id = $input['semester_id'] ?? null;
    
    if (!$name && $code) { $name = $code; $code = null; }
    if (!$code) {
        $extracted = extractCodeAndName($name);
        $code = $extracted['code'];
        $name = $extracted['name'];
    }
    if (!$name || !$semester_id) { http_response_code(400); echo json_encode(['error' => 'Campos requeridos']); exit; }
    
    execute("INSERT INTO subjects (code, name, semester_id) VALUES (?, ?, ?)", [$code, $name, $semester_id]);
    echo json_encode(queryOne("SELECT * FROM subjects ORDER BY id DESC LIMIT 1"));
    exit;
}
if ($method === 'POST' && $request_uri === '/subjects/bulk') {
    $subjects = $input['subjects'] ?? [];
    $semester_id = $input['semester_id'] ?? null;
    if (empty($subjects) || !$semester_id) { http_response_code(400); echo json_encode(['error' => 'Datos requeridos']); exit; }
    
    $results = [];
    foreach ($subjects as $item) {
        try {
            $code = $item['code'] ?? null;
            $name = $item['name'] ?? null;
            if (!$code) {
                $ext = extractCodeAndName($name);
                $code = $ext['code'];
                $name = $ext['name'];
            }
            execute("INSERT INTO subjects (code, name, semester_id) VALUES (?, ?, ?)", [$code, $name, $semester_id]);
            $item['success'] = true;
            $results[] = $item;
        } catch(Exception $e) {
            $item['error'] = $e->getMessage();
            $results[] = $item;
        }
    }
    http_response_code(201);
    echo json_encode($results);
    exit;
}
if ($method === 'PUT' && matchRoute('/subjects/:id', $request_uri, $params)) {
    $id = $params['id'];
    if (isset($input['code'])) execute("UPDATE subjects SET code = ? WHERE id = ?", [$input['code'], $id]);
    if (isset($input['name'])) execute("UPDATE subjects SET name = ? WHERE id = ?", [$input['name'], $id]);
    if (isset($input['completed'])) execute("UPDATE subjects SET completed = ? WHERE id = ?", [$input['completed'] ? 1 : 0, $id]);
    echo json_encode(queryOne("SELECT * FROM subjects WHERE id = ?", [$id]));
    exit;
}
if ($method === 'DELETE' && matchRoute('/subjects/:id', $request_uri, $params)) {
    execute("DELETE FROM subjects WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}

// ========== FILMING ASSIGNMENTS ==========
if ($method === 'GET' && $request_uri === '/assignments') {
    echo json_encode(queryAll("SELECT fa.*, s.code as subject_code, s.name as subject_name FROM filming_assignments fa JOIN subjects s ON s.id = fa.subject_id JOIN semesters sem ON sem.id = s.semester_id AND sem.is_active = 1 ORDER BY fa.created_at DESC"));
    exit;
}
if ($method === 'GET' && matchRoute('/assignments/:id', $request_uri, $params)) {
    $a = queryOne("SELECT fa.*, s.code as subject_code, s.name as subject_name FROM filming_assignments fa JOIN subjects s ON s.id = fa.subject_id WHERE fa.id = ?", [$params['id']]);
    if (!$a) { http_response_code(404); echo json_encode(['error' => 'No encontrada']); exit; }
    $a['sessions'] = queryAll("SELECT rs.*, u1.name as staff_1_name, u2.name as staff_2_name FROM recording_sessions rs LEFT JOIN users u1 ON rs.staff_1_id = u1.id LEFT JOIN users u2 ON rs.staff_2_id = u2.id WHERE rs.assignment_id = ? ORDER BY rs.session_date ASC", [$params['id']]);
    echo json_encode($a);
    exit;
}
if ($method === 'POST' && $request_uri === '/assignments') {
    $teacher_name = $input['teacher_name'] ?? null;
    $phone = $input['phone'] ?? null;
    $subject_id = $input['subject_id'] ?? null;
    $drive_link = $input['drive_link'] ?? null;
    $script_status = $input['script_status'] ?? 'pending';
    $session = $input['session'] ?? null;
    
    if (!$teacher_name || !$subject_id) { http_response_code(400); echo json_encode(['error' => 'Docente y materia requeridos']); exit; }
    
    execute("INSERT INTO filming_assignments (teacher_name, phone, subject_id, drive_link, script_status) VALUES (?, ?, ?, ?, ?)", [$teacher_name, $phone, $subject_id, $drive_link, $script_status]);
    $assignment_id = $pdo->lastInsertId();
    
    if ($session && isset($session['session_date']) && isset($session['start_time']) && isset($session['end_time'])) {
        $hito_reached = $session['hito_reached'] ?? null;
        $notes = $session['notes'] ?? null;
        execute("INSERT INTO recording_sessions (assignment_id, session_date, start_time, end_time, hito_reached, notes) VALUES (?, ?, ?, ?, ?, ?)", [$assignment_id, $session['session_date'], $session['start_time'], $session['end_time'], $hito_reached, $notes]);
        if ($hito_reached) {
            execute("UPDATE filming_assignments SET last_hito_reached = ? WHERE id = ?", [$hito_reached, $assignment_id]);
        }
    }
    
    http_response_code(201);
    echo json_encode(queryOne("SELECT fa.*, s.code as subject_code, s.name as subject_name FROM filming_assignments fa JOIN subjects s ON s.id = fa.subject_id WHERE fa.id = ?", [$assignment_id]));
    exit;
}
if ($method === 'PUT' && matchRoute('/assignments/:id', $request_uri, $params)) {
    $id = $params['id'];
    if (isset($input['teacher_name'])) execute("UPDATE filming_assignments SET teacher_name = ? WHERE id = ?", [$input['teacher_name'], $id]);
    if (isset($input['phone'])) execute("UPDATE filming_assignments SET phone = ? WHERE id = ?", [$input['phone'], $id]);
    if (isset($input['drive_link'])) execute("UPDATE filming_assignments SET drive_link = ? WHERE id = ?", [$input['drive_link'], $id]);
    if (isset($input['script_status'])) execute("UPDATE filming_assignments SET script_status = ? WHERE id = ?", [$input['script_status'], $id]);
    if (isset($input['status'])) {
        execute("UPDATE filming_assignments SET status = ? WHERE id = ?", [$input['status'], $id]);
        if ($input['status'] === 'completed') {
            $a = queryOne("SELECT subject_id FROM filming_assignments WHERE id = ?", [$id]);
            if ($a) execute("UPDATE subjects SET completed = 1 WHERE id = ?", [$a['subject_id']]);
        }
    }
    echo json_encode(queryOne("SELECT fa.*, s.code as subject_code, s.name as subject_name FROM filming_assignments fa JOIN subjects s ON s.id = fa.subject_id WHERE fa.id = ?", [$id]));
    exit;
}
if ($method === 'DELETE' && matchRoute('/assignments/:id', $request_uri, $params)) {
    execute("DELETE FROM filming_assignments WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}

// ========== SESSIONS ==========
if ($method === 'GET' && $request_uri === '/sessions') {
    $month = $_GET['month'] ?? null;
    $year = $_GET['year'] ?? null;
    $q = "SELECT rs.*, fa.teacher_name, fa.phone, fa.subject_id, fa.drive_link, fa.script_status, fa.status as assignment_status, fa.id as assignment_id, s.code as subject_code, s.name as subject_name, u1.name as staff_1_name, u2.name as staff_2_name FROM recording_sessions rs JOIN filming_assignments fa ON fa.id = rs.assignment_id JOIN subjects s ON s.id = fa.subject_id JOIN semesters sem ON sem.id = s.semester_id AND sem.is_active = 1 LEFT JOIN users u1 ON rs.staff_1_id = u1.id LEFT JOIN users u2 ON rs.staff_2_id = u2.id";
    $sqlParams = [];
    if ($month && $year) {
        $m = str_pad($month, 2, '0', STR_PAD_LEFT);
        $q .= " WHERE rs.session_date LIKE ?";
        $sqlParams[] = "$year-$m-%";
    }
    $q .= " ORDER BY rs.session_date ASC, rs.start_time ASC";
    echo json_encode(queryAll($q, $sqlParams));
    exit;
}
if ($method === 'POST' && $request_uri === '/sessions') {
    $assignment_id = $input['assignment_id'] ?? null;
    $session_date = $input['session_date'] ?? null;
    $start_time = $input['start_time'] ?? null;
    $end_time = $input['end_time'] ?? null;
    $hito_reached = $input['hito_reached'] ?? null;
    $notes = $input['notes'] ?? null;
    $staff_1_id = !empty($input['staff_1_id']) ? $input['staff_1_id'] : null;
    $staff_2_id = !empty($input['staff_2_id']) ? $input['staff_2_id'] : null;

    if (!$assignment_id || !$session_date || !$start_time || !$end_time) { http_response_code(400); echo json_encode(['error' => 'Campos requeridos']); exit; }

    execute("INSERT INTO recording_sessions (assignment_id, session_date, start_time, end_time, hito_reached, notes, staff_1_id, staff_2_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [$assignment_id, $session_date, $start_time, $end_time, $hito_reached, $notes, $staff_1_id, $staff_2_id]);
    $sessionId = $pdo->lastInsertId();

    if ($hito_reached) {
        execute("UPDATE filming_assignments SET last_hito_reached = ? WHERE id = ?", [$hito_reached, $assignment_id]);
        if ($hito_reached === 'semanas') {
            execute("UPDATE filming_assignments SET status = 'completed' WHERE id = ?", [$assignment_id]);
            $a = queryOne("SELECT subject_id FROM filming_assignments WHERE id = ?", [$assignment_id]);
            if ($a) execute("UPDATE subjects SET completed = 1 WHERE id = ?", [$a['subject_id']]);
        }
    }
    http_response_code(201);
    echo json_encode(queryOne("SELECT * FROM recording_sessions WHERE id = ?", [$sessionId]));
    exit;
}
if ($method === 'PUT' && matchRoute('/sessions/:id', $request_uri, $params)) {
    $id = $params['id'];
    if (isset($input['session_date'])) execute("UPDATE recording_sessions SET session_date = ? WHERE id = ?", [$input['session_date'], $id]);
    if (isset($input['start_time'])) execute("UPDATE recording_sessions SET start_time = ? WHERE id = ?", [$input['start_time'], $id]);
    if (isset($input['end_time'])) execute("UPDATE recording_sessions SET end_time = ? WHERE id = ?", [$input['end_time'], $id]);
    if (isset($input['hito_reached'])) execute("UPDATE recording_sessions SET hito_reached = ? WHERE id = ?", [$input['hito_reached'], $id]);
    if (isset($input['notes'])) execute("UPDATE recording_sessions SET notes = ? WHERE id = ?", [$input['notes'], $id]);
    if (array_key_exists('staff_1_id', $input)) execute("UPDATE recording_sessions SET staff_1_id = ? WHERE id = ?", [empty($input['staff_1_id']) ? null : $input['staff_1_id'], $id]);
    if (array_key_exists('staff_2_id', $input)) execute("UPDATE recording_sessions SET staff_2_id = ? WHERE id = ?", [empty($input['staff_2_id']) ? null : $input['staff_2_id'], $id]);
    
    if (isset($input['hito_reached']) && $input['hito_reached']) {
        $s = queryOne("SELECT assignment_id FROM recording_sessions WHERE id = ?", [$id]);
        if ($s) execute("UPDATE filming_assignments SET last_hito_reached = ? WHERE id = ?", [$input['hito_reached'], $s['assignment_id']]);
    }
    echo json_encode(queryOne("SELECT * FROM recording_sessions WHERE id = ?", [$id]));
    exit;
}
if ($method === 'DELETE' && matchRoute('/sessions/:id', $request_uri, $params)) {
    execute("DELETE FROM recording_sessions WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}

// ========== RESERVATIONS ==========
if ($method === 'GET' && $request_uri === '/reservations') {
    $month = $_GET['month'] ?? null;
    $year = $_GET['year'] ?? null;
    $q = "SELECT r.*, u.name as user_name FROM reservations r JOIN users u ON u.id = r.user_id";
    $sqlParams = [];
    if ($month && $year) {
        $m = str_pad($month, 2, '0', STR_PAD_LEFT);
        $q .= " WHERE r.date LIKE ?";
        $sqlParams[] = "$year-$m-%";
    }
    $q .= " ORDER BY r.date ASC, r.start_time ASC";
    echo json_encode(queryAll($q, $sqlParams));
    exit;
}
if ($method === 'POST' && $request_uri === '/reservations') {
    $start_date = $input['start_date'] ?? null;
    $end_date = $input['end_date'] ?? null;
    $start_time = $input['start_time'] ?? null;
    $end_time = $input['end_time'] ?? null;
    $reason = $input['reason'] ?? 'Reserva';
    if (!$start_date || !$end_date || !$start_time || !$end_time) { http_response_code(400); echo json_encode(['error' => 'Campos requeridos']); exit; }
    
    $currentDate = new DateTime($start_date);
    $lastDate = new DateTime($end_date);
    if ($currentDate > $lastDate) { http_response_code(400); echo json_encode(['error' => 'Rango de fechas inválido']); exit; }
    
    while ($currentDate <= $lastDate) {
        $dStr = $currentDate->format('Y-m-d');
        execute("INSERT INTO reservations (user_id, date, start_time, end_time, reason) VALUES (?, ?, ?, ?, ?)", [$user['id'], $dStr, $start_time, $end_time, $reason]);
        $currentDate->modify('+1 day');
    }
    http_response_code(201);
    echo json_encode(['success' => true]);
    exit;
}
if ($method === 'DELETE' && matchRoute('/reservations/:id', $request_uri, $params)) {
    $resv = queryOne("SELECT * FROM reservations WHERE id = ?", [$params['id']]);
    if (!$resv) { http_response_code(404); echo json_encode(['error' => 'No encontrada']); exit; }
    if ($user['role'] !== 'admin' && $user['role'] !== 'post_productor' && $resv['user_id'] != $user['id']) { http_response_code(403); echo json_encode(['error' => 'No tienes permiso']); exit; }
    
    execute("DELETE FROM reservations WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}

// ========== PENDING TEACHERS ==========
if ($method === 'GET' && $request_uri === '/pending-teachers') {
    $showResolved = isset($_GET['resolved']) && $_GET['resolved'] === '1';
    $q = $showResolved
        ? "SELECT pt.*, u.name as added_by_name FROM pending_teachers pt LEFT JOIN users u ON u.id = pt.added_by_user_id ORDER BY pt.resolved ASC, pt.created_at DESC"
        : "SELECT pt.*, u.name as added_by_name FROM pending_teachers pt LEFT JOIN users u ON u.id = pt.added_by_user_id WHERE pt.resolved = 0 ORDER BY pt.created_at DESC";
    echo json_encode(queryAll($q));
    exit;
}
if ($method === 'POST' && $request_uri === '/pending-teachers') {
    $name = $input['name'] ?? null;
    $subject_code = $input['subject_code'] ?? null;
    $subject = $input['subject'] ?? null;
    $phone = $input['phone'] ?? null;
    $sede = $input['sede'] ?? 'La Paz';
    $is_external = !empty($input['is_external']) ? 1 : 0;
    $notes = $input['notes'] ?? null;
    
    if (!$name || !$subject) { http_response_code(400); echo json_encode(['error' => 'Nombre y materia son requeridos']); exit; }
    
    if (!$subject_code) {
        $ext = extractCodeAndName($subject);
        $subject_code = $ext['code'];
        $subject = $ext['name'];
    }

    execute("INSERT INTO pending_teachers (name, subject_code, subject, phone, sede, is_external, notes, added_by_user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [$name, $subject_code, $subject, $phone, $sede, $is_external, $notes, $user['id']]);
    $id = $pdo->lastInsertId();
    $teacher = queryOne("SELECT pt.*, u.name as added_by_name FROM pending_teachers pt LEFT JOIN users u ON u.id = pt.added_by_user_id WHERE pt.id = ?", [$id]);
    logAction("Agregó docente pendiente: $name", 'pending_teacher', $id, "$subject_code $subject");
    http_response_code(201);
    echo json_encode($teacher);
    exit;
}
if ($method === 'PUT' && matchRoute('/pending-teachers/:id', $request_uri, $params)) {
    $id = $params['id'];
    $subject = $input['subject'] ?? null;
    $subject_code = $input['subject_code'] ?? null;
    
    if ($subject !== null && $subject_code === null) {
        $ext = extractCodeAndName($subject);
        $subject_code = $ext['code'];
        $subject = $ext['name'];
    }
    
    if (isset($input['name'])) execute("UPDATE pending_teachers SET name = ? WHERE id = ?", [$input['name'], $id]);
    if ($subject_code !== null) execute("UPDATE pending_teachers SET subject_code = ? WHERE id = ?", [$subject_code, $id]);
    if ($subject !== null) execute("UPDATE pending_teachers SET subject = ? WHERE id = ?", [$subject, $id]);
    if (isset($input['phone'])) execute("UPDATE pending_teachers SET phone = ? WHERE id = ?", [$input['phone'], $id]);
    if (isset($input['sede'])) execute("UPDATE pending_teachers SET sede = ? WHERE id = ?", [$input['sede'], $id]);
    if (isset($input['is_external'])) execute("UPDATE pending_teachers SET is_external = ? WHERE id = ?", [$input['is_external'] ? 1 : 0, $id]);
    if (isset($input['notes'])) execute("UPDATE pending_teachers SET notes = ? WHERE id = ?", [$input['notes'], $id]);
    if (isset($input['resolved'])) {
        execute("UPDATE pending_teachers SET resolved = ? WHERE id = ?", [$input['resolved'] ? 1 : 0, $id]);
        logAction($input['resolved'] ? "Marcó docente como resuelto" : "Reabrió docente", 'pending_teacher', $id);
    } else {
        logAction("Editó docente pendiente", 'pending_teacher', $id, $input['name'] ?? '');
    }
    echo json_encode(queryOne("SELECT pt.*, u.name as added_by_name FROM pending_teachers pt LEFT JOIN users u ON u.id = pt.added_by_user_id WHERE pt.id = ?", [$id]));
    exit;
}
if ($method === 'DELETE' && matchRoute('/pending-teachers/:id', $request_uri, $params)) {
    $t = queryOne("SELECT * FROM pending_teachers WHERE id = ?", [$params['id']]);
    if ($t) logAction("Eliminó docente pendiente: {$t['name']}", 'pending_teacher', $t['id']);
    execute("DELETE FROM pending_teachers WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}

// ========== STAFF & USERS ==========
if ($method === 'GET' && $request_uri === '/staff') {
    echo json_encode(queryAll("SELECT id, name, role FROM users WHERE role IN ('post_productor', 'admin') ORDER BY name ASC"));
    exit;
}
if ($method === 'GET' && $request_uri === '/users') { isAdmin(); echo json_encode(queryAll("SELECT id, username, role, name, created_at FROM users ORDER BY created_at ASC")); exit; }
if ($method === 'POST' && $request_uri === '/users') {
    isAdmin();
    $username = $input['username'] ?? null;
    $password = $input['password'] ?? null;
    $role = $input['role'] ?? null;
    $name = $input['name'] ?? null;
    if (!$username || !$password || !$role || !$name) { http_response_code(400); echo json_encode(['error' => 'Todos los campos son requeridos']); exit; }
    if (!in_array($role, ['admin', 'post_productor', 'academica'])) { http_response_code(400); echo json_encode(['error' => 'Rol inválido']); exit; }
    try {
        execute("INSERT INTO users (username, password, role, name) VALUES (?, ?, ?, ?)", [$username, $password, $role, $name]);
        $id = $pdo->lastInsertId();
        logAction("Creó usuario: $name ($role)", 'user', $id);
        http_response_code(201);
        echo json_encode(queryOne("SELECT id, username, role, name, created_at FROM users WHERE id = ?", [$id]));
    } catch(Exception $e) {
        http_response_code(409); echo json_encode(['error' => 'El nombre de usuario ya existe']);
    }
    exit;
}
if ($method === 'PUT' && matchRoute('/users/:id', $request_uri, $params)) {
    isAdmin();
    $id = $params['id'];
    if (isset($input['username'])) execute("UPDATE users SET username = ? WHERE id = ?", [$input['username'], $id]);
    if (isset($input['password']) && $input['password'] !== '') execute("UPDATE users SET password = ? WHERE id = ?", [$input['password'], $id]);
    if (isset($input['role'])) execute("UPDATE users SET role = ? WHERE id = ?", [$input['role'], $id]);
    if (isset($input['name'])) execute("UPDATE users SET name = ? WHERE id = ?", [$input['name'], $id]);
    logAction("Editó usuario #$id", 'user', $id);
    echo json_encode(queryOne("SELECT id, username, role, name, created_at FROM users WHERE id = ?", [$id]));
    exit;
}
if ($method === 'DELETE' && matchRoute('/users/:id', $request_uri, $params)) {
    isAdmin();
    if ($params['id'] == $user['id']) { http_response_code(400); echo json_encode(['error' => 'No puedes eliminarte a ti mismo']); exit; }
    $u = queryOne("SELECT * FROM users WHERE id = ?", [$params['id']]);
    if ($u) logAction("Eliminó usuario: {$u['name']}", 'user', $u['id']);
    execute("DELETE FROM users WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}

// ========== OTHERS ==========
if ($method === 'GET' && $request_uri === '/closed-weeks') { echo json_encode(queryAll("SELECT * FROM closed_weeks ORDER BY week_start DESC")); exit; }
if ($method === 'POST' && $request_uri === '/closed-weeks') {
    $week_start = $input['week_start'] ?? null;
    $reason = $input['reason'] ?? 'Estudio cerrado';
    if (!$week_start) { http_response_code(400); echo json_encode(['error' => 'Fecha requerida']); exit; }
    try {
        execute("INSERT INTO closed_weeks (week_start, reason) VALUES (?, ?)", [$week_start, $reason]);
        http_response_code(201);
        echo json_encode(queryOne("SELECT * FROM closed_weeks ORDER BY id DESC LIMIT 1"));
    } catch(Exception $e) { http_response_code(409); echo json_encode(['error' => 'Semana ya cerrada']); }
    exit;
}
if ($method === 'DELETE' && matchRoute('/closed-weeks/:id', $request_uri, $params)) { execute("DELETE FROM closed_weeks WHERE id = ?", [$params['id']]); echo json_encode(['success' => true]); exit; }

if ($method === 'GET' && preg_match('/^\/availability\/(.+)$/', $request_uri, $matches)) {
    $date = $matches[1];
    $timestamp = strtotime("$date 12:00:00");
    $dow = date('w', $timestamp);
    $monOff = $dow == 0 ? -6 : 1 - $dow;
    $mon = date('Y-m-d', strtotime("$monOff days", $timestamp));

    $closed = queryOne("SELECT * FROM closed_weeks WHERE week_start = ?", [$mon]);
    if ($closed) { echo json_encode(['closed' => true, 'reason' => $closed['reason'], 'slots' => []]); exit; }

    $startH = intval(explode(':', queryOne("SELECT value FROM settings WHERE `key` = 'studio_start_time'")['value'] ?? '08:00')[0]);
    $endH = intval(explode(':', queryOne("SELECT value FROM settings WHERE `key` = 'studio_end_time'")['value'] ?? '18:00')[0]);

    $existing = queryAll("SELECT rs.start_time, rs.end_time, fa.teacher_name, s.code as subject_code FROM recording_sessions rs JOIN filming_assignments fa ON fa.id = rs.assignment_id JOIN subjects s ON s.id = fa.subject_id WHERE rs.session_date = ? ORDER BY rs.start_time ASC", [$date]);

    $slots = [];
    for ($h = $startH; $h < $endH; $h++) {
        $ss = sprintf("%02d:00", $h);
        $se = sprintf("%02d:00", $h + 1);
        $occ = null;
        foreach ($existing as $s) {
            if (($ss >= $s['start_time'] && $ss < $s['end_time']) || ($se > $s['start_time'] && $se <= $s['end_time'])) {
                $occ = $s; break;
            }
        }
        $slots[] = ['start' => $ss, 'end' => $se, 'available' => !$occ, 'session' => $occ];
    }
    echo json_encode(['closed' => false, 'slots' => $slots, 'existingSessions' => $existing]);
    exit;
}

if ($method === 'GET' && $request_uri === '/activity-log') { isAdmin(); $limit = $_GET['limit'] ?? 50; echo json_encode(queryAll("SELECT * FROM activity_log ORDER BY created_at DESC LIMIT " . intval($limit))); exit; }

if ($method === 'GET' && preg_match('/^\/global-subjects$/', $request_uri)) {
    $q = $_GET['q'] ?? null;
    if ($q) {
        $qParam = "%$q%";
        echo json_encode(queryAll("SELECT * FROM global_subjects WHERE code LIKE ? OR name LIKE ? ORDER BY code ASC LIMIT 50", [$qParam, $qParam]));
    } else {
        echo json_encode(queryAll("SELECT * FROM global_subjects ORDER BY code ASC"));
    }
    exit;
}
if ($method === 'POST' && $request_uri === '/global-subjects') {
    isAdmin();
    $code = $input['code'] ?? null;
    $name = $input['name'] ?? null;
    $career = $input['career'] ?? null;
    if (!$code || !$name) { http_response_code(400); echo json_encode(['error' => 'Código y nombre requeridos']); exit; }
    try {
        execute("INSERT INTO global_subjects (code, name, career) VALUES (?, ?, ?)", [$code, $name, $career]);
        $id = $pdo->lastInsertId();
        logAction("Agregó materia global: $code - $name", 'global_subject', $id);
        http_response_code(201);
        echo json_encode(queryOne("SELECT * FROM global_subjects WHERE id = ?", [$id]));
    } catch(Exception $e) {
        http_response_code(409); echo json_encode(['error' => 'Esa materia ya existe']);
    }
    exit;
}
if ($method === 'POST' && $request_uri === '/global-subjects/bulk') {
    isAdmin();
    $subjects = $input['subjects'] ?? [];
    if (!is_array($subjects) || empty($subjects)) { http_response_code(400); echo json_encode(['error' => 'Lista requerida']); exit; }
    $inserted = 0; $skipped = 0;
    foreach ($subjects as $s) {
        try {
            execute("INSERT IGNORE INTO global_subjects (code, name, career) VALUES (?, ?, ?)", [$s['code'], $s['name'], $s['career'] ?? null]);
            if ($pdo->lastInsertId()) $inserted++; else $skipped++;
        } catch(Exception $e) { $skipped++; }
    }
    logAction("Importó $inserted materias globales", 'global_subject');
    echo json_encode(['inserted' => $inserted, 'skipped' => $skipped]);
    exit;
}
if ($method === 'DELETE' && matchRoute('/global-subjects/:id', $request_uri, $params)) {
    isAdmin();
    execute("DELETE FROM global_subjects WHERE id = ?", [$params['id']]);
    echo json_encode(['success' => true]);
    exit;
}

http_response_code(404);
echo json_encode(['error' => 'Ruta no encontrada']);
