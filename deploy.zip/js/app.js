// ================================================
// App Controller — Main application logic
// ================================================

const App = {
    currentView: 'calendar',
    activeSemester: null,
    user: null,

    async init() {
        // Check Auth
        const token = localStorage.getItem('edtech_token');
        if (token) {
            const user = await API.get('/me', true);
            if (user && !user.error) {
                this.user = user;
                this.startApp();
            } else {
                this.showLogin();
            }
        } else {
            this.showLogin();
        }

        // Bind login form
        document.getElementById('form-login').addEventListener('submit', async (e) => {
            e.preventDefault();
            const u = document.getElementById('login-user').value;
            const p = document.getElementById('login-pass').value;
            const res = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p }) }).then(r => r.json());
            if (res.error) return showToast(res.error, 'error');
            localStorage.setItem('edtech_token', res.token);
            this.user = res.user;
            this.startApp();
        });

        // Logout
        document.getElementById('btn-logout')?.addEventListener('click', async () => {
            await API.post('/logout');
            localStorage.removeItem('edtech_token');
            location.reload();
        });
    },

    async startApp() {
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('app-wrapper').style.display = 'block';
        
        document.getElementById('current-user-name').textContent = this.user.name;
        
        // Show role badge
        const roleBadge = document.getElementById('user-role-badge');
        if (roleBadge) {
            const roleLabels = { admin: 'Admin', post_productor: 'Post-Producción', academica: 'Académica' };
            const roleClasses = { admin: 'role-admin', post_productor: 'role-postprod', academica: 'role-academica' };
            roleBadge.textContent = roleLabels[this.user.role] || this.user.role;
            roleBadge.className = `role-badge ${roleClasses[this.user.role] || ''}`;
        }

        this.applyRolePermissions();
        this.bindNavigation();
        await this.loadActiveSemester();
        Calendar.init();
        Dashboard.refresh();
        Modals.init();

        // Académica starts on Agenda Pendientes
        if (this.user.role === 'academica') {
            this.switchView('pending-teachers');
        }
    },

    applyRolePermissions() {
        const role = this.user.role;
        // Admin-only elements — but skip .view sections (switchView manages those)
        document.querySelectorAll('.admin-only').forEach(el => {
            if (el.classList.contains('view')) return;
            el.style.display = role === 'admin' ? '' : 'none';
        });
        // Editor elements (admin + post_productor)
        document.querySelectorAll('.editor-only').forEach(el => {
            if (el.classList.contains('view')) return;
            el.style.display = ['admin', 'post_productor'].includes(role) ? '' : 'none';
        });
        // Academica: read-only calendar + agenda pendientes
        if (role === 'academica') {
            // Hide nav items not relevant
            document.querySelectorAll('.nav-btn:not([data-view="calendar"]):not([data-view="pending-teachers"])').forEach(el => el.style.display = 'none');
            // Hide ALL calendar action buttons (new filmación, close week, reserve)
            document.querySelectorAll('.calendar-actions').forEach(el => el.style.display = 'none');
            // Hide dashboard cards (internal studio stats)
            const dashCards = document.getElementById('dashboard-cards');
            if (dashCards) dashCards.style.display = 'none';
            // Hide progress bar
            const progressEl = document.querySelector('.progress-section');
            if (progressEl) progressEl.style.display = 'none';
        }
    },

    bindNavigation() {
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const view = btn.dataset.view;
                this.switchView(view);
            });
        });
    },

    switchView(view) {
        this.currentView = view;
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        document.querySelector(`[data-view="${view}"]`)?.classList.add('active');
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById(`view-${view}`)?.classList.add('active');

        if (view === 'goals') Goals.refresh();
        if (view === 'pending-teachers') PendingTeachers.refresh();
        if (view === 'admin') AdminPanel.refresh();
    },

    async loadActiveSemester() {
        const semesters = await API.get('/semesters');
        if (semesters && !semesters.error) {
            this.activeSemester = semesters.find(s => s.is_active);
            this.updateSemesterBadge();
        }
    },

    updateSemesterBadge() {
        const badge = document.getElementById('semester-badge');
        if (this.activeSemester) {
            badge.textContent = `Semestre ${this.activeSemester.name}`;
            badge.style.background = 'var(--accent-bg)';
            badge.style.color = 'var(--accent)';
        } else {
            badge.textContent = 'Sin semestre activo';
            badge.style.background = 'var(--amber-bg)';
            badge.style.color = 'var(--amber)';
        }
    },

    showLogin() {
        document.getElementById('login-screen').style.display = 'flex';
        document.getElementById('app-wrapper').style.display = 'none';
    }
};


// ================================================
// API Helper
// ================================================

const API = {
    getHeaders() {
        const token = localStorage.getItem('edtech_token');
        return token ? { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` } : { 'Content-Type': 'application/json' };
    },
    async checkAuth(res, silent) {
        if (res.status === 401 && !silent) {
            localStorage.removeItem('edtech_token');
            location.reload();
        }
        return res.json();
    },
    async get(url, silent = false) {
        const res = await fetch(`/api${url}`, { headers: this.getHeaders() });
        return this.checkAuth(res, silent);
    },
    async post(url, data) {
        const res = await fetch(`/api${url}`, { method: 'POST', headers: this.getHeaders(), body: JSON.stringify(data) });
        return this.checkAuth(res);
    },
    async put(url, data) {
        const res = await fetch(`/api${url}`, { method: 'PUT', headers: this.getHeaders(), body: JSON.stringify(data) });
        return this.checkAuth(res);
    },
    async del(url) {
        const res = await fetch(`/api${url}`, { method: 'DELETE', headers: this.getHeaders() });
        return this.checkAuth(res);
    }
};

// ================================================
// Toast notifications
// ================================================

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.3s'; setTimeout(() => toast.remove(), 300); }, 3000);
}

// ================================================
// Hito labels
// ================================================

const HITO_LABELS = {
    pagina_inicio: 'Pág. Inicio',
    hito_2: 'Hito II',
    hito_3: 'Hito III',
    hito_4: 'Hito IV',
    hito_5: 'Hito V',
    semanas: 'Semanas'
};

const SCRIPT_LABELS = {
    pending: 'Pendiente',
    in_progress: 'En Progreso',
    completed: 'Terminado'
};

// ================================================
// Goals management
// ================================================

const Goals = {
    subjects: [],

    async refresh() {
        if (!App.activeSemester) {
            document.getElementById('goals-subtitle').textContent = 'Primero crea un semestre';
            return;
        }
        document.getElementById('goals-subtitle').textContent = `Semestre ${App.activeSemester.name}`;
        this.subjects = await API.get(`/subjects?semester_id=${App.activeSemester.id}`);
        this.render();
    },

    render() {
        const list = document.getElementById('subjects-list');
        const empty = document.getElementById('subjects-empty');
        const subjects = this.subjects;

        // Stats
        const total = subjects.length;
        const completed = subjects.filter(s => s.completed).length;
        const inProg = subjects.filter(s => s.assignment_status === 'in_progress').length;
        const pending = total - completed - inProg;

        document.getElementById('goals-total').textContent = total;
        document.getElementById('goals-completed').textContent = completed;
        document.getElementById('goals-inprogress').textContent = inProg;
        document.getElementById('goals-pending-stat').textContent = Math.max(0, pending);

        if (subjects.length === 0) {
            list.innerHTML = '';
            list.appendChild(empty.cloneNode ? document.getElementById('subjects-empty').cloneNode(true) : empty);
            empty.style.display = '';
            return;
        }

        // Remove empty state  
        const existingEmpty = list.querySelector('.empty-state');
        if (existingEmpty) existingEmpty.remove();

        let html = '';
        for (const s of subjects) {
            let statusClass = 's-pending';
            let statusText = 'Pendiente';
            if (s.completed) { statusClass = 's-completed'; statusText = 'Completada'; }
            else if (s.assignment_status === 'in_progress') { statusClass = 's-in_progress'; statusText = 'En progreso'; }

            const hitoText = s.last_hito_reached ? HITO_LABELS[s.last_hito_reached] || '' : '';

            const canEdit = App.user && ['admin', 'post_productor'].includes(App.user.role);

            html += `<div class="subject-item" data-id="${s.id}">
                <span class="subject-code">${s.code}</span>
                <span class="subject-name">${s.name}</span>
                ${hitoText ? `<span class="subject-hito">Último: ${hitoText}</span>` : ''}
                <span class="subject-status ${statusClass}">${statusText}</span>
                <div class="subject-actions">
                    ${canEdit ? `
                    <button class="btn-icon" style="color: ${s.completed ? 'var(--green)' : 'var(--text-muted)'};" onclick="Goals.toggleComplete(${s.id}, ${s.completed})" title="${s.completed ? 'Desmarcar' : 'Completar'}">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    </button>
                    ` : ''}
                    <button class="btn-icon" onclick="Goals.deleteSubject(${s.id})" title="Eliminar">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                </div>
            </div>`;
        }
        list.innerHTML = html;
    },

    async toggleComplete(id, currentState) {
        await API.put(`/subjects/${id}`, { completed: !currentState });
        showToast(currentState ? 'Materia desmarcada' : 'Materia completada', 'success');
        this.refresh();
        Dashboard.refresh();
    },

    async deleteSubject(id) {
        Calendar.showConfirm({
            title: 'Eliminar Materia',
            message: '¿Eliminar esta materia? Si tiene filmaciones asignadas también se eliminarán.'
        }, async () => {
            await API.del(`/subjects/${id}`);
            showToast('Materia eliminada', 'success');
            this.refresh();
            Dashboard.refresh();
        });
    }
};

// ================================================
// Init
// ================================================

document.addEventListener('DOMContentLoaded', () => App.init());
