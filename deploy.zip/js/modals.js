// ================================================
// Modals Module
// ================================================

const Modals = {
    currentAssignmentId: null,

    init() {
        // Close modal on overlay click or close buttons
        document.getElementById('modal-overlay').addEventListener('click', () => this.closeAll());
        document.querySelectorAll('[data-close-modal]').forEach(btn => {
            btn.addEventListener('click', () => this.closeAll());
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') this.closeAll();
        });

        // Bind all modal triggers
        document.getElementById('btn-new-assignment').addEventListener('click', () => this.openNewAssignment());
        document.getElementById('btn-close-week').addEventListener('click', () => this.openCloseWeek());
        document.getElementById('btn-manage-semester').addEventListener('click', () => this.openSemesterManager());
        document.getElementById('btn-add-subject').addEventListener('click', () => this.openAddSubject());
        document.getElementById('btn-bulk-import').addEventListener('click', () => this.openBulkImport());
        document.getElementById('btn-settings').addEventListener('click', () => this.openSemesterManager());
        document.getElementById('btn-new-reservation')?.addEventListener('click', () => this.openNewReservation());

        // Save handlers
        document.getElementById('btn-create-semester').addEventListener('click', () => this.createSemester());
        document.getElementById('btn-save-subject').addEventListener('click', () => this.saveSubject());
        document.getElementById('btn-do-import').addEventListener('click', () => this.doBulkImport());
        document.getElementById('btn-save-assignment').addEventListener('click', () => this.saveAssignment());
        document.getElementById('btn-do-close-week').addEventListener('click', () => this.doCloseWeek());
        document.getElementById('btn-save-session').addEventListener('click', () => this.saveNewSession());
        document.getElementById('btn-detail-add-session').addEventListener('click', () => this.openAddSession());
        document.getElementById('btn-detail-complete').addEventListener('click', () => this.markComplete());
        document.getElementById('btn-save-reservation')?.addEventListener('click', () => this.saveReservation());

        // Pending teachers integration
        document.getElementById('input-select-pending')?.addEventListener('change', (e) => {
            if (!e.target.value) {
                document.getElementById('input-teacher-name').value = '';
                document.getElementById('input-teacher-phone').value = '';
                document.getElementById('input-assignment-subject').value = '';
                return;
            }
            const pt = Modals.pendingTeachersData?.find(t => t.id == e.target.value);
            if (pt) {
                document.getElementById('input-teacher-name').value = pt.name;
                document.getElementById('input-teacher-phone').value = pt.phone || '';
                
                const subjectSelect = document.getElementById('input-assignment-subject');
                const subjectOptions = Array.from(subjectSelect.options);
                
                const normalize = str => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
                const ptSubj = normalize(pt.subject);
                const ptCode = pt.subject_code ? normalize(pt.subject_code) : null;
                
                // Find best match
                let match = subjectOptions.find(opt => {
                    const optText = normalize(opt.text);
                    if (ptCode && optText.includes(ptCode)) return true;
                    return optText === ptSubj || optText.includes(ptSubj) || ptSubj.includes(optText);
                });
                
                if (match) {
                    subjectSelect.value = match.value;
                } else {
                    subjectSelect.value = '';
                }
            }
        });
    },

    open(modalId) {
        document.getElementById('modal-overlay').classList.add('active');
        document.getElementById(modalId).classList.add('active');
    },

    closeAll() {
        document.getElementById('modal-overlay').classList.remove('active');
        document.querySelectorAll('.modal.active').forEach(m => m.classList.remove('active'));
    },

    // ===== SEMESTER MANAGER =====

    async openSemesterManager() {
        this.open('modal-semester');
        const semesters = await API.get('/semesters');
        const list = document.getElementById('semester-list');
        if (semesters.length === 0) {
            list.innerHTML = '<p style="color:var(--text-muted);font-size:13px;text-align:center;padding:20px;">No hay semestres creados</p>';
            return;
        }
        list.innerHTML = semesters.map(s => `
            <div class="semester-item ${s.is_active ? 'is-active' : ''}">
                <span class="semester-item-name">${s.name} ${s.is_active ? '(Activo)' : ''}</span>
                <div class="semester-item-actions">
                    ${!s.is_active ? `<button class="btn-sm btn-outline" onclick="Modals.activateSemester(${s.id})">Activar</button>` : ''}
                    <button class="btn-icon" onclick="Modals.deleteSemester(${s.id})" title="Eliminar">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                </div>
            </div>
        `).join('');
    },

    async createSemester() {
        const name = document.getElementById('input-semester-name').value.trim();
        if (!name) return showToast('Ingresa un nombre', 'error');
        const result = await API.post('/semesters', { name });
        if (result.error) return showToast(result.error, 'error');
        document.getElementById('input-semester-name').value = '';
        showToast(`Semestre "${name}" creado`, 'success');
        await App.loadActiveSemester();
        this.openSemesterManager();
        Dashboard.refresh();
        Calendar.render();
    },

    async activateSemester(id) {
        await API.put(`/semesters/${id}/activate`);
        await App.loadActiveSemester();
        showToast('Semestre activado', 'success');
        this.openSemesterManager();
        Dashboard.refresh();
        Calendar.render();
        Goals.refresh();
    },

    async deleteSemester(id) {
        Calendar.showConfirm({
            title: 'Eliminar Semestre',
            message: '¿Eliminar este semestre y todas sus materias? Esta acción no se puede deshacer.'
        }, async () => {
            await API.del(`/semesters/${id}`);
            await App.loadActiveSemester();
            showToast('Semestre eliminado', 'success');
            this.openSemesterManager();
            Dashboard.refresh();
            Calendar.render();
        });
    },

    // ===== ADD SUBJECT =====

    openAddSubject() {
        if (!App.activeSemester) return showToast('Primero crea un semestre', 'error');
        document.getElementById('input-subject-name').value = '';
        this.open('modal-subject');
    },

    async saveSubject() {
        const name = document.getElementById('input-subject-name').value.trim();
        if (!name) return showToast('Ingresa el nombre o materia', 'error');
        const result = await API.post('/subjects', { name, semester_id: App.activeSemester.id });
        if (result.error) return showToast(result.error, 'error');
        showToast(`Materia agregada`, 'success');
        this.closeAll();
        Goals.refresh();
        Dashboard.refresh();
    },

    // ===== BULK IMPORT =====

    openBulkImport() {
        if (!App.activeSemester) return showToast('Primero crea un semestre', 'error');
        document.getElementById('input-bulk-text').value = '';
        this.open('modal-bulk-import');
    },

    async doBulkImport() {
        const text = document.getElementById('input-bulk-text').value.trim();
        if (!text) return showToast('Pega la lista de materias', 'error');

        const lines = text.split('\n').filter(l => l.trim());
        const subjects = [];
        for (const line of lines) {
            const trimmed = line.trim();
            // Try to extract code (first word with dash) and name (rest)
            const match = trimmed.match(/^([A-Za-z]+-\d+)\s+(.+)$/);
            if (match) {
                subjects.push({ code: match[1].toUpperCase(), name: match[2].trim() });
            } else {
                // Fallback: first space separates code and name
                const spaceIdx = trimmed.indexOf(' ');
                if (spaceIdx > 0) {
                    subjects.push({ code: trimmed.substring(0, spaceIdx).toUpperCase(), name: trimmed.substring(spaceIdx + 1).trim() });
                }
            }
        }

        if (subjects.length === 0) return showToast('No se pudieron parsear las materias', 'error');

        const result = await API.post('/subjects/bulk', { subjects, semester_id: App.activeSemester.id });
        const successCount = result.filter(r => r.success || !r.error).length;
        showToast(`${successCount} materias importadas`, 'success');
        this.closeAll();
        Goals.refresh();
        Dashboard.refresh();
    },

    // ===== NEW ASSIGNMENT =====

    async openNewAssignment() {
        if (!App.activeSemester) return showToast('Primero crea un semestre', 'error');

        // Reset form
        document.getElementById('input-teacher-name').value = '';
        document.getElementById('input-teacher-phone').value = '';
        document.getElementById('input-drive-link').value = '';
        document.getElementById('input-script-status').value = 'pending';
        document.getElementById('input-session-hito').value = '';

        // Load subjects into dropdown
        const subjects = await API.get(`/subjects?semester_id=${App.activeSemester.id}`);
        const select = document.getElementById('input-assignment-subject');
        select.innerHTML = '<option value="">Seleccionar materia...</option>';
        subjects.filter(s => !s.completed).forEach(s => {
            select.innerHTML += `<option value="${s.id}">${s.code} — ${s.name}</option>`;
        });

        // Load pending teachers
        const pendingTeachers = await API.get('/pending-teachers?resolved=0');
        Modals.pendingTeachersData = pendingTeachers;
        const ptSelect = document.getElementById('input-select-pending');
        const ptRow = document.getElementById('row-select-pending');
        ptSelect.innerHTML = '<option value="">-- Ingreso manual --</option>';
        if (pendingTeachers.length > 0) {
            pendingTeachers.forEach(t => {
                ptSelect.innerHTML += `<option value="${t.id}">${t.name} (${t.subject})</option>`;
            });
            ptRow.style.display = '';
        } else {
            ptRow.style.display = 'none';
        }

        // Set default date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('input-session-date').value = today;

        document.getElementById('modal-assignment-title').textContent = 'Nueva Filmación';
        this.open('modal-assignment');
    },

    async saveAssignment() {
        const teacher_name = document.getElementById('input-teacher-name').value.trim();
        const phone = document.getElementById('input-teacher-phone').value.trim();
        const subject_id = document.getElementById('input-assignment-subject').value;
        const drive_link = document.getElementById('input-drive-link').value.trim();
        const script_status = document.getElementById('input-script-status').value;

        if (!teacher_name || !subject_id) return showToast('Nombre del docente y materia son requeridos', 'error');

        const session_date = document.getElementById('input-session-date').value;
        const start_time = document.getElementById('input-session-start').value;
        const end_time = document.getElementById('input-session-end').value;
        const hito_reached = document.getElementById('input-session-hito').value;

        const session = (session_date && start_time && end_time) ? { session_date, start_time, end_time, hito_reached } : null;

        const result = await API.post('/assignments', { teacher_name, phone, subject_id, drive_link, script_status, session });
        if (result.error) return showToast(result.error, 'error');

        // Check if we loaded from pending teachers to mark it as resolved
        const pendingId = document.getElementById('input-select-pending')?.value;
        if (pendingId) {
            await API.put(`/pending-teachers/${pendingId}`, { resolved: 1 });
            if (typeof PendingTeachers !== 'undefined' && App.currentView === 'pending-teachers') {
                PendingTeachers.refresh();
            }
        }

        showToast('Filmación creada exitosamente', 'success');
        this.closeAll();
        Calendar.render();
        Dashboard.refresh();
        if (App.currentView === 'goals') Goals.refresh();
    },

    // ===== NEW RESERVATION =====

    openNewReservation() {
        if (!App.activeSemester) return showToast('Primero crea un semestre', 'error');

        // Set default date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('input-res-date').value = today;
        document.getElementById('input-res-end-date').value = today;
        document.getElementById('input-res-start').value = '08:00';
        document.getElementById('input-res-end').value = '10:00';
        document.getElementById('input-res-reason').value = '';

        this.open('modal-reservation');
    },

    async saveReservation() {
        const start_date = document.getElementById('input-res-date').value;
        const end_date = document.getElementById('input-res-end-date').value;
        const start_time = document.getElementById('input-res-start').value;
        const end_time = document.getElementById('input-res-end').value;
        const reason = document.getElementById('input-res-reason').value.trim();

        if (!start_date || !end_date || !start_time || !end_time || !reason) return showToast('Todos los campos son obligatorios', 'error');
        if (new Date(start_date) > new Date(end_date)) return showToast('Fecha fin no puede ser menor a fecha inicio', 'error');

        const result = await API.post('/reservations', { start_date, end_date, start_time, end_time, reason });
        if (result.error) return showToast(result.error, 'error');

        showToast('Reserva guardada', 'success');
        this.closeAll();
        Calendar.render();
    },

    // ===== CLOSE WEEK =====

    openCloseWeek() {
        // Default to next Monday
        const now = new Date();
        const day = now.getDay();
        const diff = day === 0 ? 1 : (8 - day);
        const nextMon = new Date(now);
        nextMon.setDate(now.getDate() + diff);
        document.getElementById('input-close-week-date').value = nextMon.toISOString().split('T')[0];
        document.getElementById('input-close-week-reason').value = 'Estudio cerrado';
        this.open('modal-close-week');
    },

    async doCloseWeek() {
        const week_start = document.getElementById('input-close-week-date').value;
        const reason = document.getElementById('input-close-week-reason').value.trim();
        if (!week_start) return showToast('Selecciona la fecha', 'error');

        const result = await API.post('/closed-weeks', { week_start, reason });
        if (result.error) return showToast(result.error, 'error');

        showToast('Semana cerrada', 'success');
        this.closeAll();
        Calendar.render();
    },

    // ===== ASSIGNMENT DETAIL =====

    async showAssignmentDetail(assignmentId) {
        this.currentAssignmentId = assignmentId;
        const data = await API.get(`/assignments/${assignmentId}`);
        if (data.error) return showToast(data.error, 'error');

        document.getElementById('detail-title').textContent = `${data.subject_code} — ${data.subject_name}`;

        const scriptClass = `script-${data.script_status}`;
        const scriptText = SCRIPT_LABELS[data.script_status] || data.script_status;

        let html = `<div class="detail-grid">
            <div class="detail-field">
                <div class="detail-field-label">Docente</div>
                <div class="detail-field-value">${data.teacher_name}</div>
            </div>
            <div class="detail-field">
                <div class="detail-field-label">Teléfono</div>
                <div class="detail-field-value">${data.phone || '—'}</div>
            </div>
            <div class="detail-field">
                <div class="detail-field-label">Estado del Guión</div>
                <div class="detail-field-value"><span class="script-badge ${scriptClass}">${scriptText}</span></div>
            </div>
            <div class="detail-field">
                <div class="detail-field-label">Link del Guión</div>
                <div class="detail-field-value">${data.drive_link ? `<a href="${data.drive_link}" target="_blank">Abrir en Drive ↗</a>` : '—'}</div>
            </div>
            <div class="detail-field">
                <div class="detail-field-label">Último Hito</div>
                <div class="detail-field-value">${data.last_hito_reached ? HITO_LABELS[data.last_hito_reached] : 'Sin registrar'}</div>
            </div>
            <div class="detail-field">
                <div class="detail-field-label">Estado</div>
                <div class="detail-field-value">${data.status === 'completed' ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 4px;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg> Completada' : data.status === 'cancelled' ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 4px;"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg> Cancelada' : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 4px;"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg> En progreso'}</div>
            </div>
        </div>`;

        // Edit section
        html += `<div class="divider"></div>
        <div class="detail-edit-row">
            <label style="font-size:12px;font-weight:600;color:var(--text-secondary);white-space:nowrap;">Guión:</label>
            <select class="input select" onchange="Modals.updateAssignmentField('script_status', this.value)" style="max-width:180px;">
                <option value="pending" ${data.script_status==='pending'?'selected':''}>Pendiente</option>
                <option value="in_progress" ${data.script_status==='in_progress'?'selected':''}>En Progreso</option>
                <option value="completed" ${data.script_status==='completed'?'selected':''}>Terminado</option>
            </select>
            <input type="url" class="input" placeholder="Link de Drive" value="${data.drive_link || ''}" onchange="Modals.updateAssignmentField('drive_link', this.value)" style="max-width:300px;">
        </div>`;

        // Sessions list
        html += `<div class="divider"></div>
        <div class="detail-sessions-title">Sesiones de Grabación (${data.sessions?.length || 0})</div>`;

        if (data.sessions && data.sessions.length > 0) {
            for (const s of data.sessions) {
                const hitoClass = s.hito_reached ? `hito-${s.hito_reached}` : '';
                const hitoText = s.hito_reached ? HITO_LABELS[s.hito_reached] : '';
                const dateParts = s.session_date.split('-');
                const dateF = `${dateParts[2]}/${dateParts[1]}/${dateParts[0]}`;
                html += `<div class="detail-session">
                    <span class="detail-session-date">${dateF}</span>
                    <span class="detail-session-time">${s.start_time?.substring(0,5)} - ${s.end_time?.substring(0,5)}</span>
                    ${hitoText ? `<span class="detail-session-hito ${hitoClass}">${hitoText}</span>` : ''}
                    <span class="detail-session-notes">
                        ${s.staff_1_name ? `<span style="display:inline-block; margin-right:8px; padding:2px 6px; background:var(--bg-tertiary); border-radius:4px; font-size:11px; color:var(--text-secondary);"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:-1px; margin-right:3px;"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>${s.staff_1_name}${s.staff_2_name ? ` + ${s.staff_2_name}` : ''}</span>` : ''}
                        ${s.notes || ''}
                    </span>
                    <button class="btn-icon" onclick="Modals.deleteSession(${s.id})" title="Eliminar sesión">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                    </button>
                </div>`;
            }
        } else {
            html += '<p style="color:var(--text-muted);font-size:13px;">No hay sesiones registradas</p>';
        }

        document.getElementById('detail-body').innerHTML = html;

        // Show/hide complete button
        const completeBtn = document.getElementById('btn-detail-complete');
        completeBtn.style.display = data.status === 'in_progress' ? '' : 'none';

        this.open('modal-detail');
    },

    async updateAssignmentField(field, value) {
        if (!this.currentAssignmentId) return;
        await API.put(`/assignments/${this.currentAssignmentId}`, { [field]: value });
        showToast('Actualizado', 'success');
        // Refresh detail without closing
        this.showAssignmentDetail(this.currentAssignmentId);
    },

    async deleteSession(sessionId) {
        Calendar.showConfirm({
            title: 'Eliminar Sesión',
            message: '¿Eliminar esta sesión de grabación?'
        }, async () => {
            await API.del(`/sessions/${sessionId}`);
            showToast('Sesión eliminada', 'success');
            this.showAssignmentDetail(this.currentAssignmentId);
            Calendar.render();
        });
    },

    async markComplete() {
        if (!this.currentAssignmentId) return;
        Calendar.showConfirm({
            title: 'Completar Filmación',
            message: '¿Marcar esta filmación como completada?',
            okLabel: 'Completar'
        }, async () => {
            await API.put(`/assignments/${this.currentAssignmentId}`, { status: 'completed' });
            showToast('Filmación marcada como completada', 'success');
            this.closeAll();
            Calendar.render();
            Dashboard.refresh();
            if (App.currentView === 'goals') Goals.refresh();
        });
    },

    // ===== ADD SESSION (to existing) =====

    async openAddSession() {
        if (!this.currentAssignmentId) return;
        // Pre-fill context
        const title = document.getElementById('detail-title').textContent;
        document.getElementById('session-context').innerHTML = `
            <div class="session-context-teacher">${title}</div>
        `;
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('input-new-session-date').value = today;
        document.getElementById('input-new-session-hito').value = '';
        document.getElementById('input-new-session-notes').value = '';

        // Load staff
        const s1 = document.getElementById('input-new-session-staff-1');
        const s2 = document.getElementById('input-new-session-staff-2');
        const staff = await API.get('/staff');
        s1.innerHTML = '<option value="">Seleccionar...</option>';
        s2.innerHTML = '<option value="">Ninguno</option>';
        staff.forEach(u => {
            s1.innerHTML += `<option value="${u.id}">${u.name}</option>`;
            s2.innerHTML += `<option value="${u.id}">${u.name}</option>`;
        });

        this.closeAll();
        this.open('modal-add-session');
    },

    async saveNewSession() {
        const assignment_id = this.currentAssignmentId;
        const session_date = document.getElementById('input-new-session-date').value;
        const start_time = document.getElementById('input-new-session-start').value;
        const end_time = document.getElementById('input-new-session-end').value;
        const hito_reached = document.getElementById('input-new-session-hito').value;
        const notes = document.getElementById('input-new-session-notes').value.trim();
        const staff_1_id = document.getElementById('input-new-session-staff-1').value;
        const staff_2_id = document.getElementById('input-new-session-staff-2').value;

        if (!session_date || !start_time || !end_time) return showToast('Completa fecha y horario', 'error');

        const result = await API.post('/sessions', { assignment_id, session_date, start_time, end_time, hito_reached, notes, staff_1_id, staff_2_id });
        if (result.error) return showToast(result.error, 'error');

        showToast('Sesión agregada', 'success');
        this.closeAll();
        Calendar.render();
        Dashboard.refresh();
        if (App.currentView === 'goals') Goals.refresh();
    }
};
