// ================================================
// Calendar Module — with right-click menu, Ctrl+Z undo, custom confirm
// ================================================

const Calendar = {
    currentYear: new Date().getFullYear(),
    currentMonth: new Date().getMonth(),
    sessions: [],
    closedWeeks: [],
    reservations: [],

    // Undo stack: [{type, data, restoreFn}]
    undoStack: [],

    MONTH_NAMES: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],

    init() {
        document.getElementById('btn-prev-month').addEventListener('click', () => this.changeMonth(-1));
        document.getElementById('btn-next-month').addEventListener('click', () => this.changeMonth(1));
        document.getElementById('btn-today').addEventListener('click', () => {
            this.currentYear = new Date().getFullYear();
            this.currentMonth = new Date().getMonth();
            this.render();
        });

        // Hide context menu on any outside click or scroll
        document.addEventListener('click', () => this.hideCtxMenu());
        document.addEventListener('scroll', () => this.hideCtxMenu(), true);
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
                e.preventDefault();
                this.undo();
            }
            if (e.key === 'Escape') this.hideCtxMenu();
        });

        this.render();
    },

    changeMonth(delta) {
        this.currentMonth += delta;
        if (this.currentMonth > 11) { this.currentMonth = 0; this.currentYear++; }
        if (this.currentMonth < 0) { this.currentMonth = 11; this.currentYear--; }
        this.render();
    },

    async render() {
        document.getElementById('calendar-month-title').textContent =
            `${this.MONTH_NAMES[this.currentMonth]} ${this.currentYear}`;

        const [sessions, closedWeeks, reservations] = await Promise.all([
            API.get(`/sessions?month=${this.currentMonth + 1}&year=${this.currentYear}`),
            API.get('/closed-weeks'),
            API.get(`/reservations?month=${this.currentMonth + 1}&year=${this.currentYear}`)
        ]);
        this.sessions = sessions;
        this.closedWeeks = closedWeeks;
        this.reservations = reservations;

        this.renderGrid();
    },

    getMonday(date) {
        const d = new Date(date);
        const day = d.getDay();
        const diff = day === 0 ? -6 : 1 - day;
        d.setDate(d.getDate() + diff);
        return d.toISOString().split('T')[0];
    },

    isWeekClosed(dateStr) {
        const monday = this.getMonday(dateStr);
        return this.closedWeeks.find(w => w.week_start === monday);
    },

    renderGrid() {
        const grid = document.getElementById('calendar-grid');
        const headers = Array.from(grid.querySelectorAll('.cal-header'));
        grid.innerHTML = '';
        headers.forEach(h => grid.appendChild(h));

        const year = this.currentYear;
        const month = this.currentMonth;
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);

        let startOffset = firstDay.getDay() - 1;
        if (startOffset < 0) startOffset = 6;

        const today = new Date();
        const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

        const prevMonthLast = new Date(year, month, 0).getDate();
        for (let i = startOffset - 1; i >= 0; i--) {
            const dayNum = prevMonthLast - i;
            const m = month === 0 ? 12 : month;
            const y = month === 0 ? year - 1 : year;
            const dateStr = `${y}-${String(m).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
            grid.appendChild(this.createDayCell(dayNum, dateStr, true, false, false));
        }

        for (let d = 1; d <= lastDay.getDate(); d++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
            const isToday = dateStr === todayStr;
            const dayOfWeek = new Date(year, month, d).getDay();
            const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
            grid.appendChild(this.createDayCell(d, dateStr, false, isToday, isWeekend));
        }

        const totalCells = grid.querySelectorAll('.cal-day').length;
        const remaining = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
        for (let i = 1; i <= remaining; i++) {
            const m = month + 2 > 12 ? 1 : month + 2;
            const y = month + 2 > 12 ? year + 1 : year;
            const dateStr = `${y}-${String(m).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            grid.appendChild(this.createDayCell(i, dateStr, true, false, false));
        }
    },

    createDayCell(dayNum, dateStr, isOtherMonth, isToday, isWeekend) {
        const cell = document.createElement('div');
        cell.className = 'cal-day';
        if (isOtherMonth) cell.classList.add('other-month');
        if (isToday) cell.classList.add('today');
        if (isWeekend) cell.classList.add('weekend');

        const closedWeek = this.isWeekClosed(dateStr);
        if (closedWeek) cell.classList.add('closed');

        cell.innerHTML = `<div class="cal-day-num">${dayNum}</div>`;

        if (closedWeek) {
            cell.innerHTML += `<div class="cal-closed-label"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: baseline; margin-right: 2px;"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> Cerrado</div>`;
            cell.title = closedWeek.reason || 'Estudio cerrado';
        }

        // Sessions
        const daySessions = this.sessions.filter(s => s.session_date === dateStr);
        const maxShow = 3;
        daySessions.slice(0, maxShow).forEach(session => {
            const ev = document.createElement('div');
            ev.className = `cal-event status-${session.assignment_status || 'in_progress'}`;
            ev.innerHTML = `
                <div class="cal-event-header">
                    <span class="cal-event-time">${session.start_time?.substring(0, 5)}</span>
                    <span class="cal-event-code">${session.subject_code}</span>
                </div>
                <div class="cal-event-subject">${session.subject_name}</div>
                <div class="cal-event-teacher">${session.teacher_name}</div>
            `;
            ev.title = `${session.teacher_name} — ${session.subject_name}\n${session.start_time} - ${session.end_time}`;

            // Click to view detail (only editors)
            if (App.user && App.user.role !== 'academica') {
                ev.style.cursor = 'pointer';
                ev.addEventListener('click', (e) => {
                    e.stopPropagation();
                    Modals.showAssignmentDetail(session.assignment_id);
                });
            }

            // Right-click context menu on sessions (only for editors)
            if (App.user && ['admin', 'post_productor'].includes(App.user.role)) {
                ev.addEventListener('contextmenu', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.showCtxMenu(e.clientX, e.clientY, [
                        {
                            label: 'Ver detalle',
                            icon: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
                            action: () => Modals.showAssignmentDetail(session.assignment_id)
                        },
                        { separator: true },
                        {
                            label: `Eliminar sesión`,
                            icon: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
                            danger: true,
                            action: () => this.confirmDeleteSession(session)
                        }
                    ]);
                });
            }

            cell.appendChild(ev);
        });

        // Reservations
        const dayReservations = this.reservations?.filter(r => r.date === dateStr) || [];
        dayReservations.forEach(r => {
            const ev = document.createElement('div');
            
            const currentD = new Date(r.date + 'T00:00:00');
            const prevD = new Date(currentD); prevD.setDate(prevD.getDate() - 1);
            const nextD = new Date(currentD); nextD.setDate(nextD.getDate() + 1);
            
            const prevStr = prevD.toISOString().split('T')[0];
            const nextStr = nextD.toISOString().split('T')[0];
            
            const hasPrev = this.reservations.some(r2 => r2.date === prevStr && r2.user_id === r.user_id && r2.reason === r.reason && r2.start_time === r.start_time);
            const hasNext = this.reservations.some(r2 => r2.date === nextStr && r2.user_id === r.user_id && r2.reason === r.reason && r2.start_time === r.start_time);
            
            let spanClass = '';
            if (hasPrev && hasNext) spanClass = 'span-middle';
            else if (!hasPrev && hasNext) spanClass = 'span-start';
            else if (hasPrev && !hasNext) spanClass = 'span-end';

            ev.className = `cal-event reservation ${spanClass}`;
            const hideText = spanClass === 'span-middle' || spanClass === 'span-end' ? 'opacity: 0;' : '';
            ev.innerHTML = `
                <div class="cal-event-header" style="${hideText}">
                    <span class="cal-event-time">${r.start_time?.substring(0, 5)}</span>
                    <span class="cal-event-code">RESERVA</span>
                </div>
                <div class="cal-event-subject" style="${hideText}">${r.reason || 'Bloqueado'}</div>
                <div class="cal-event-teacher" style="${hideText}">Por: ${r.user_name}</div>
            `;
            ev.title = `Motivo: ${r.reason}\n${r.start_time} - ${r.end_time}`;

            const canDelete = App.user && (App.user.role === 'admin' || App.user.role === 'post_productor' || App.user.id === r.user_id);

            if (canDelete) {
                ev.style.cursor = 'pointer';
                ev.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.confirmDeleteReservation(r);
                });
                ev.addEventListener('contextmenu', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.showCtxMenu(e.clientX, e.clientY, [
                        {
                            label: `Reserva: ${r.user_name}`,
                            header: true
                        },
                        {
                            label: 'Eliminar reserva',
                            icon: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>',
                            danger: true,
                            action: () => this.confirmDeleteReservation(r)
                        }
                    ]);
                });
            }

            cell.appendChild(ev);
        });

        // Right-click on closed cell to open/delete the week close
        if (closedWeek && App.user && ['admin', 'post_productor'].includes(App.user.role)) {
            cell.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                this.showCtxMenu(e.clientX, e.clientY, [
                    { label: closedWeek.reason || 'Semana cerrada', header: true },
                    {
                        label: 'Reabrir semana',
                        icon: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/><line x1="12" y1="15" x2="12" y2="19"/></svg>',
                        action: async () => {
                            await API.del(`/closed-weeks/${closedWeek.id}`);
                            this.undoStack.push({
                                label: `Semana reabierta (${closedWeek.week_start})`,
                                undo: async () => {
                                    await API.post('/closed-weeks', { week_start: closedWeek.week_start, reason: closedWeek.reason });
                                    this.render();
                                }
                            });
                            showToast('Semana reabierta', 'success', true);
                            this.render();
                        }
                    }
                ]);
            });
        }

        if (daySessions.length + dayReservations.length > maxShow) {
            const more = document.createElement('div');
            more.className = 'cal-more';
            more.textContent = `+${daySessions.length + dayReservations.length - maxShow} más`;
            cell.appendChild(more);
        }

        if (!closedWeek && !isOtherMonth && App.user && App.user.role !== 'academica') {
            cell.addEventListener('click', () => {
                const sd = document.getElementById('input-session-date');
                const nsd = document.getElementById('input-new-session-date');
                if (sd) sd.value = dateStr;
                if (nsd) nsd.value = dateStr;
            });
        }

        return cell;
    },

    // ---- Context Menu ----
    showCtxMenu(x, y, items) {
        const menu = document.getElementById('ctx-menu');
        const container = document.getElementById('ctx-menu-items');
        container.innerHTML = '';

        items.forEach(item => {
            if (item.separator) {
                const sep = document.createElement('div');
                sep.className = 'ctx-separator';
                container.appendChild(sep);
                return;
            }
            if (item.header) {
                const hdr = document.createElement('div');
                hdr.className = 'ctx-header';
                hdr.textContent = item.label;
                container.appendChild(hdr);
                return;
            }
            const el = document.createElement('div');
            el.className = `ctx-item${item.danger ? ' ctx-danger' : ''}${item.disabled ? ' ctx-disabled' : ''}`;
            el.innerHTML = `${item.icon || ''}${item.label}`;
            el.addEventListener('click', (e) => {
                e.stopPropagation();
                this.hideCtxMenu();
                item.action?.();
            });
            container.appendChild(el);
        });

        menu.style.display = 'block';

        // Position — keep inside viewport
        const rect = menu.getBoundingClientRect();
        const vw = window.innerWidth, vh = window.innerHeight;
        let left = x, top = y;
        if (x + 200 > vw) left = x - 200;
        if (y + container.children.length * 38 > vh) top = y - (container.children.length * 38);
        menu.style.left = `${left}px`;
        menu.style.top = `${top}px`;
    },

    hideCtxMenu() {
        document.getElementById('ctx-menu').style.display = 'none';
    },

    // ---- Custom Confirm Dialog ----
    showConfirm({ title, message, okLabel = 'Eliminar' } = {}, onOk) {
        const overlay = document.getElementById('confirm-overlay');
        document.getElementById('confirm-title').textContent = title || '¿Confirmar acción?';
        document.getElementById('confirm-message').textContent = message || '';
        document.getElementById('confirm-ok').textContent = okLabel;
        document.getElementById('confirm-icon').innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`;
        overlay.style.display = 'flex';

        const cancel = document.getElementById('confirm-cancel');
        const ok = document.getElementById('confirm-ok');

        const cleanup = () => {
            overlay.style.display = 'none';
            ok.replaceWith(ok.cloneNode(true));
            cancel.replaceWith(cancel.cloneNode(true));
        };

        document.getElementById('confirm-ok').addEventListener('click', () => {
            cleanup();
            onOk?.();
        });
        document.getElementById('confirm-cancel').addEventListener('click', cleanup);

        // ESC to close
        const escHandler = (e) => {
            if (e.key === 'Escape') { cleanup(); document.removeEventListener('keydown', escHandler); }
        };
        document.addEventListener('keydown', escHandler);
    },

    // ---- Delete helpers ----
    async confirmDeleteSession(session) {
        this.showConfirm({
            title: 'Eliminar sesión',
            message: `¿Eliminar la sesión de ${session.teacher_name} (${session.subject_code}) del ${session.session_date}?`
        }, async () => {
            // Save for undo
            const backup = { ...session };
            await API.del(`/sessions/${session.id}`);
            this.undoStack.push({
                label: `Sesión de ${session.subject_code}`,
                undo: async () => {
                    await API.post('/sessions', {
                        assignment_id: backup.assignment_id,
                        session_date: backup.session_date,
                        start_time: backup.start_time,
                        end_time: backup.end_time,
                        hito_reached: backup.hito_reached,
                        notes: backup.notes
                    });
                    this.render();
                }
            });
            showToastWithUndo(`Sesión eliminada`);
            this.render();
        });
    },

    async confirmDeleteReservation(r) {
        this.showConfirm({
            title: 'Eliminar reserva',
            message: `¿Eliminar la reserva de ${r.user_name} del ${r.date} (${r.start_time} - ${r.end_time})?`
        }, async () => {
            const backup = { ...r };
            await API.del(`/reservations/${r.id}`);
            this.undoStack.push({
                label: `Reserva de ${r.user_name}`,
                undo: async () => {
                    await API.post('/reservations', {
                        start_date: backup.date, end_date: backup.date,
                        start_time: backup.start_time, end_time: backup.end_time,
                        reason: backup.reason
                    });
                    this.render();
                }
            });
            showToastWithUndo(`Reserva eliminada`);
            this.render();
        });
    },

    // ---- Ctrl+Z Undo ----
    async undo() {
        if (this.undoStack.length === 0) {
            showToast('Nada para deshacer', 'info');
            return;
        }
        const last = this.undoStack.pop();
        showToast(`Deshaciendo: ${last.label}...`, 'info');
        await last.undo();
    }
};

// Extended showToast with undo button
function showToastWithUndo(message) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast toast-success`;
    toast.innerHTML = `${message} <button class="toast-undo-btn" onclick="Calendar.undo()">↩ Deshacer</button>`;
    container.appendChild(toast);
    let timer = setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.3s'; setTimeout(() => toast.remove(), 300); }, 5000);
    toast.querySelector('.toast-undo-btn').addEventListener('click', () => {
        clearTimeout(timer);
        toast.remove();
    });
}
