// ================================================
// Pending Teachers Module — Agenda de Docentes
// ================================================

const PendingTeachers = {
    teachers: [],
    showResolved: false,
    editingId: null,

    init() {
        // Quick add
        document.getElementById('btn-quick-add').addEventListener('click', () => this.quickAdd());
        document.getElementById('qa-name').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.quickAdd(); });
        document.getElementById('qa-subject').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.quickAdd(); });
        document.getElementById('qa-phone').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.quickAdd(); });

        // Modal add
        document.getElementById('btn-add-pending-teacher').addEventListener('click', () => this.openModal());
        document.getElementById('btn-save-pending-teacher').addEventListener('click', () => this.saveFromModal());

        // Close modal delegates (already handled by Modals.init but we need the new modal's close buttons)
        document.querySelectorAll('#modal-pending-teacher [data-close-modal]').forEach(btn => {
            btn.addEventListener('click', () => Modals.closeAll());
        });

        // Toggle resolved
        document.getElementById('toggle-show-resolved').addEventListener('change', (e) => {
            this.showResolved = e.target.checked;
            this.refresh();
        });
    },

    async refresh() {
        const resolved = this.showResolved ? '1' : '0';
        this.teachers = await API.get(`/pending-teachers?resolved=${resolved}`);
        this.render();
    },

    render() {
        const list = document.getElementById('pending-list');
        const teachers = this.teachers;

        // Stats
        const pending = teachers.filter(t => !t.resolved).length;
        const external = teachers.filter(t => t.is_external && !t.resolved).length;
        const resolved = teachers.filter(t => t.resolved).length;

        document.getElementById('pt-total').textContent = pending;
        document.getElementById('pt-external').textContent = external;
        document.getElementById('pt-resolved').textContent = resolved;

        if (teachers.length === 0) {
            list.innerHTML = `
                <div class="empty-state">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    <p>No hay docentes pendientes</p>
                    <span>Agrega docentes usando el formulario rápido o el botón superior</span>
                </div>`;
            return;
        }

        let html = '';
        for (const t of teachers) {
            const isExt = t.is_external;
            const isResolved = t.resolved;
            const cardClass = `pt-card${isExt ? ' pt-external' : ''}${isResolved ? ' pt-resolved' : ''}`;

            const sedeIcon = isExt
                ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`
                : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>`;

            const phoneDisplay = t.phone
                ? `<a href="https://wa.me/${t.phone.replace(/[^0-9]/g, '')}" target="_blank" class="pt-phone-link" title="Abrir en WhatsApp">${t.phone}</a>`
                : '<span class="pt-no-phone">Sin número</span>';

            const dateCreated = new Date(t.created_at).toLocaleDateString('es-BO', { day: '2-digit', month: 'short' });

            html += `<div class="${cardClass}" data-id="${t.id}">
                <div class="pt-card-main">
                    <div class="pt-avatar">${t.name.charAt(0).toUpperCase()}</div>
                    <div class="pt-info">
                        <div class="pt-name">${t.name}</div>
                        <div class="pt-subject">${t.subject_code ? `<span class="pt-subject-code">${t.subject_code}</span> ` : ''}${t.subject}</div>
                    </div>
                    <div class="pt-meta">
                        <div class="pt-sede-badge ${isExt ? 'sede-external' : ''}">
                            ${sedeIcon}
                            <span>${t.sede}</span>
                            ${isExt ? '<span class="ext-tag">EXTERNO</span>' : ''}
                        </div>
                        <div class="pt-phone">${phoneDisplay}</div>
                    </div>
                    ${App.user && (App.user.role !== 'academica' || t.added_by_user_id === App.user.id) ? `<div class="pt-actions">
                        <button class="btn-icon" onclick="PendingTeachers.editTeacher(${t.id})" title="Editar">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>
                        </button>
                        ${!isResolved ? `<button class="btn-icon pt-btn-resolve" onclick="PendingTeachers.toggleResolved(${t.id}, true)" title="Marcar como resuelto">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                        </button>` : `<button class="btn-icon pt-btn-unresolve" onclick="PendingTeachers.toggleResolved(${t.id}, false)" title="Reabrir">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
                        </button>`}
                        <button class="btn-icon" onclick="PendingTeachers.deleteTeacher(${t.id})" title="Eliminar">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                    </div>` : ''}
                </div>
                ${t.notes ? `<div class="pt-notes">${t.notes}</div>` : ''}
                <div class="pt-date">
                    ${t.added_by_name ? `<span class="pt-added-by">Añadido por <strong>${t.added_by_name}</strong> · </span>` : ''}${dateCreated}
                </div>
            </div>`;
        }
        list.innerHTML = html;
    },

    async quickAdd() {
        const name = document.getElementById('qa-name').value.trim();
        const subject = document.getElementById('qa-subject').value.trim();
        const phone = document.getElementById('qa-phone').value.trim();
        const sede = document.getElementById('qa-sede').value;
        const is_external = (sede !== 'La Paz' && sede !== 'El Alto');

        if (!name || !subject) return showToast('Nombre y materia son requeridos', 'error');

        const result = await API.post('/pending-teachers', { name, subject, phone, sede, is_external });
        if (result.error) return showToast(result.error, 'error');

        // Clear fields
        document.getElementById('qa-name').value = '';
        document.getElementById('qa-subject').value = '';
        document.getElementById('qa-phone').value = '';
        document.getElementById('qa-sede').value = 'La Paz';

        showToast(`Docente "${name}" agregado`, 'success');
        this.refresh();
    },

    openModal() {
        this.editingId = null;
        document.getElementById('modal-pt-title').textContent = 'Agregar Docente Pendiente';
        document.getElementById('input-pt-name').value = '';
        document.getElementById('input-pt-subject').value = '';
        document.getElementById('input-pt-phone').value = '';
        document.getElementById('input-pt-sede').value = 'La Paz';
        document.getElementById('input-pt-notes').value = '';
        Modals.open('modal-pending-teacher');
    },

    editTeacher(id) {
        const t = this.teachers.find(x => x.id === id);
        if (!t) return;
        this.editingId = id;
        document.getElementById('modal-pt-title').textContent = 'Editar Docente Pendiente';
        document.getElementById('input-pt-name').value = t.name;
        document.getElementById('input-pt-subject').value = t.subject;
        document.getElementById('input-pt-phone').value = t.phone || '';
        document.getElementById('input-pt-sede').value = t.sede || 'La Paz';
        document.getElementById('input-pt-notes').value = t.notes || '';
        Modals.open('modal-pending-teacher');
    },

    async saveFromModal() {
        const name = document.getElementById('input-pt-name').value.trim();
        const subject = document.getElementById('input-pt-subject').value.trim();
        const phone = document.getElementById('input-pt-phone').value.trim();
        const sede = document.getElementById('input-pt-sede').value;
        const is_external = (sede !== 'La Paz' && sede !== 'El Alto');
        const notes = document.getElementById('input-pt-notes').value.trim();

        if (!name || !subject) return showToast('Nombre y materia son requeridos', 'error');

        const data = { name, subject, phone, sede, is_external, notes };

        if (this.editingId) {
            await API.put(`/pending-teachers/${this.editingId}`, data);
            showToast('Docente actualizado', 'success');
        } else {
            const result = await API.post('/pending-teachers', data);
            if (result.error) return showToast(result.error, 'error');
            showToast(`Docente "${name}" agregado`, 'success');
        }

        Modals.closeAll();
        this.refresh();
    },

    async toggleResolved(id, resolved) {
        await API.put(`/pending-teachers/${id}`, { resolved });
        showToast(resolved ? 'Marcado como resuelto' : 'Reabierto', 'success');
        this.refresh();
    },

    async deleteTeacher(id) {
        const t = this.teachers.find(x => x.id === id);
        Calendar.showConfirm({
            title: 'Eliminar de Agenda',
            message: `¿Eliminar a "${t?.name || 'este docente'}" de la agenda de pendientes?`
        }, async () => {
            await API.del(`/pending-teachers/${id}`);
            showToast('Docente eliminado', 'success');
            this.refresh();
        });
    }
};

// Init when DOM is ready (after App.init)
document.addEventListener('DOMContentLoaded', () => {
    // Small delay to ensure Modals is initialized first
    setTimeout(() => PendingTeachers.init(), 100);
});
